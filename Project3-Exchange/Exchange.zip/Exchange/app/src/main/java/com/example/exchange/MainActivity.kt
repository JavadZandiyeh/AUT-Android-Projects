package com.example.exchange

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.exchange.databinding.ActivityMainBinding
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    companion object Currency {
        const val RIAL = "rial"
        const val US_DOLLAR = "usDollar"
        const val CA_DOLLAR = "caDollar"
        const val GB_POND = "gbPond"
        const val EURO = "euro"
        const val DIRHAM = "dirham"

        const val C_RIAL = 1.0
        const val C_US_DOLLAR = 357000.0
        const val C_CA_DOLLAR = 265700.0
        const val C_GB_POND = 425870.0
        const val C_EURO = 368110.0
        const val C_DIRHAM = 97190.0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        calculateValues()
    }

    private fun getEditTexts(): Map<String, EditText> {
        return mapOf<String, EditText>(
            RIAL to binding.rialEditText,
            US_DOLLAR to binding.usDollarEditText,
            CA_DOLLAR to binding.caDollarEditText,
            GB_POND to binding.gbPondEditText,
            EURO to binding.euroEditText,
            DIRHAM to binding.dirhamEditText
        )
    }

    private fun getBaseCurrencyValues(): Map<String, Double> {
        return mapOf(
            RIAL to C_RIAL,
            US_DOLLAR to C_US_DOLLAR,
            CA_DOLLAR to C_CA_DOLLAR,
            GB_POND to C_GB_POND,
            EURO to C_EURO,
            DIRHAM to C_DIRHAM
        )
    }

    private fun calculateValues() {
        val editTexts: Map<String, EditText> = getEditTexts()

        editTexts.forEach {
            it.value.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {}

                override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    if (it.value.hasFocus())
                        setValues(it.key, s.toString())
                }
            })
        }
    }

    private fun setValues(type: String, value: String) {
        val currencyValue: Double? = value.toDoubleOrNull()
        val editTexts: Map<String, EditText> = getEditTexts()

        if (currencyValue == null) {
            editTexts.forEach {
                it.value.text?.clear()
            }
            return
        }

        val baseCurrencyValues: Map<String, Double> = getBaseCurrencyValues()

        editTexts.forEach {
            if (type != it.key) {
                val correctCurrency =
                    ((currencyValue * baseCurrencyValues[type]!!) / baseCurrencyValues[it.key]!!)
                editTexts[it.key]?.setText(String.format("%.10f", correctCurrency).toDouble().toString())
            }
        }
    }
}
