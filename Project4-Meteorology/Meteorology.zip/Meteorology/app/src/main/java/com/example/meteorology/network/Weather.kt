//package com.example.meteorology.network
//
//data class Weather(
//    val temp: Float,
//    val main: String
//)