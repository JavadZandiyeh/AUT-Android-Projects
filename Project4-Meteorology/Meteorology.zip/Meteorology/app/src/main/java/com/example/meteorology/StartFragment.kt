package com.example.meteorology

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.meteorology.databinding.FragmentStartBinding
import com.example.meteorology.model.MeteorologyViewModel

class StartFragment : Fragment() {

    private var binding: FragmentStartBinding? = null
    private val sharedViewModel: MeteorologyViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentStartBinding.inflate(inflater, container, false)
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.apply {
            provinceCityButton.setOnClickListener {
                goToNextScreen(R.id.action_startFragment_to_provinceFragment)
            }
            mapButton.setOnClickListener {
                goToNextScreen(R.id.action_startFragment_to_mapFragment)
            }
        }
    }

    private fun goToNextScreen(actionId: Int) {
        if (sharedViewModel.hasNoProvinceSet()) {
            sharedViewModel.setProvince(getString(R.string.Tehran))
        }
        findNavController().navigate(actionId)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}