package com.example.meteorology

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.meteorology.databinding.FragmentProvinceBinding
import com.example.meteorology.model.MeteorologyViewModel


class ProvinceFragment : Fragment() {

    private var binding: FragmentProvinceBinding? = null
    private val sharedViewModel: MeteorologyViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        binding = FragmentProvinceBinding.inflate(inflater, container, false)
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.apply {
            viewModelProvince = sharedViewModel

            nextButton.setOnClickListener {
                goToNextScreen()
            }

            goToStartButton.setOnClickListener {
                goToStartScreen()
            }
        }
    }

    private fun goToStartScreen() {
        findNavController().navigate(R.id.action_provinceFragment_to_startFragment)
    }

    private fun goToNextScreen() {
        findNavController().navigate(R.id.action_provinceFragment_to_cityFragment)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}