//package com.example.meteorology.overview
//
//import android.view.LayoutInflater
//import android.view.ViewGroup
//import androidx.recyclerview.widget.DiffUtil
//import androidx.recyclerview.widget.ListAdapter
//import androidx.recyclerview.widget.RecyclerView
//import com.example.meteorology.databinding.FragmentWeatherBinding
//import com.example.meteorology.network.Weather
//
//class WeatherAdapter : ListAdapter<Weather, WeatherAdapter.WeatherViewHolder>(DiffCallback) {
//
//    class WeatherViewHolder(
//        private var binding: FragmentWeatherBinding
//    ) : RecyclerView.ViewHolder(binding.root) {
//        fun bind(weather: Weather) {
//            binding.weather = weather
//            binding.executePendingBindings()
//        }
//    }
//
//    companion object DiffCallback : DiffUtil.ItemCallback<Weather>() {
//        override fun areItemsTheSame(oldItem: Weather, newItem: Weather): Boolean {
//            return oldItem.temp == newItem.temp
//        }
//
//        override fun areContentsTheSame(oldItem: Weather, newItem: Weather): Boolean {
//            return oldItem.temp == newItem.temp
//        }
//    }
//
//    override fun onCreateViewHolder(
//        parent: ViewGroup,
//        viewType: Int
//    ): WeatherViewHolder {
//        return WeatherViewHolder(
//            FragmentWeatherBinding.inflate(LayoutInflater.from(parent.context))
//        )
//    }
//
//    override fun onBindViewHolder(holder: WeatherViewHolder, position: Int) {
//        val weather = getItem(position)
//        holder.bind(weather)
//    }
//}