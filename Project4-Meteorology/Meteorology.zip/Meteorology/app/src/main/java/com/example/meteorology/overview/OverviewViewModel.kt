//package com.example.meteorology.overview
//
//import androidx.lifecycle.LiveData
//import androidx.lifecycle.MutableLiveData
//import androidx.lifecycle.ViewModel
//import androidx.lifecycle.viewModelScope
//import com.example.meteorology.network.MeteorologyApi
//import com.example.meteorology.network.Weather
//import kotlinx.coroutines.launch
//
//enum class MeteorologyApiStatus { LOADING, ERROR, DONE }
//
//class OverviewViewModel : ViewModel() {
//
//    private val _status = MutableLiveData<MeteorologyApiStatus>()
//    val status: LiveData<MeteorologyApiStatus> = _status
//
//    private val _weathers = MutableLiveData<List<Weather>>()
//    val weathers: LiveData<List<Weather>> = _weathers
//
//    init {
//        getWeathers()
//    }
//
//    private fun getWeathers() {
//        viewModelScope.launch {
//            _status.value = MeteorologyApiStatus.LOADING
//            try {
//                _weathers.value = MeteorologyApi.retrofitService.getWeathers()
//                _status.value = MeteorologyApiStatus.DONE
//            } catch (e: Exception) {
//                _weathers.value = listOf()
//                _status.value = MeteorologyApiStatus.ERROR
//            }
//
////            val listResult = MeteorologyApi.retrofitService.getWeathers()
////            _weathers.value = listResult
//        }
//    }
//}