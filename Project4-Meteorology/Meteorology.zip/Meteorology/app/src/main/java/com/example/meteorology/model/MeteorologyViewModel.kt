package com.example.meteorology.model

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MeteorologyViewModel : ViewModel() {
    private val _province = MutableLiveData("")
    val province: LiveData<String> = _province

    private val _city = MutableLiveData("")
    val city: LiveData<String> = _city

    private val _lat = MutableLiveData(0f)
    val lat: LiveData<Float> = _lat

    private val _long = MutableLiveData(0f)
    val long: LiveData<Float> = _long

    fun setProvince(province: String) {
        _province.value = province
    }

    fun setCity(city: String) {
        _city.value = city
    }

    fun setLat(lat: Float) {
        _lat.value = lat
    }

    fun setLong(long: Float) {
        _long.value = long
    }

    fun hasNoProvinceSet(): Boolean {
        return _province.value.isNullOrEmpty()
    }
}