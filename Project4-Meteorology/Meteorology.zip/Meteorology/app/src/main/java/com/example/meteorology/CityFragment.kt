package com.example.meteorology

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.meteorology.databinding.FragmentCityBinding
import com.example.meteorology.model.MeteorologyViewModel

class CityFragment : Fragment() {

    private var binding: FragmentCityBinding? = null
    private val sharedViewModel: MeteorologyViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentCityBinding.inflate(inflater, container, false)
        return binding!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.apply {
            viewModelCity = sharedViewModel

            setCities()

            nextButton.setOnClickListener {
                val cityId: Int = cityOptions.checkedRadioButtonId
                val cityRadioButton: RadioButton = binding!!.root.findViewById(cityId)
                val city: String = cityRadioButton.text.toString()
                sharedViewModel.setCity(city)
                goToNextScreen()

            }

            goToStartButton.setOnClickListener {
                goToStartScreen()
            }
        }
    }

    private fun goToStartScreen() {
        findNavController().navigate(R.id.action_cityFragment_to_startFragment)
    }

    private fun goToNextScreen() {
        findNavController().navigate(R.id.action_cityFragment_to_weatherFragment)
    }

    private fun setCities() {
        var city1 = "شهر ۱"
        var city2 = "شهر ۲"
        var city3 = "شهر ۳"
        var city4 = "شهر ۴"
        var city5 = "شهر ۵"

        when (sharedViewModel.province.value) {
            getString(R.string.Tehran) -> {
                city1 = getString(R.string.Shemiranat)
                city2 = getString(R.string.Varamin)
                city3 = getString(R.string.FirozKoh)
                city4 = getString(R.string.Ray)
                city5 = getString(R.string.Qods)
            }
            getString(R.string.Isfahan) -> {
                city1 = getString(R.string.Kashan)
                city2 = getString(R.string.Daran)
                city3 = getString(R.string.Aran)
                city4 = getString(R.string.Tiran)
                city5 = getString(R.string.Mobarake)
            }
            getString(R.string.Shiraz) -> {
                city1 = getString(R.string.MarvDasht)
                city2 = getString(R.string.Jahrom)
                city3 = getString(R.string.Fasa)
                city4 = getString(R.string.Kazeron)
                city5 = getString(R.string.Sadra)
            }
            getString(R.string.KhorasanRazavi) -> {
                city1 = getString(R.string.Mashhad)
                city2 = getString(R.string.Neyshabor)
                city3 = getString(R.string.Ghochan)
                city4 = getString(R.string.Sabzevar)
                city5 = getString(R.string.Kariz)
            }
            getString(R.string.Qom) -> {
                city1 = getString(R.string.Kahak)
                city2 = getString(R.string.Dastjerd)
                city3 = getString(R.string.Jafarie)
                city4 = getString(R.string.Salafchegan)
                city5 = getString(R.string.Ganavat)
            }
        }

        binding?.city1?.text = city1
        binding?.city2?.text = city2
        binding?.city3?.text = city3
        binding?.city4?.text = city4
        binding?.city5?.text = city5

        sharedViewModel.setCity(city1)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        binding = null
    }
}