package com.example.jidibo

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Adapter for the [RecyclerView] in [MainActivity].
 */
class ItemAdapter(
    private val context: Context,
    private val dataset: List<Book>,
    private val isLinearLayoutManager: Boolean
) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val textView: TextView = view.findViewById(R.id.item_tile)
        val imageView: ImageView = view.findViewById(R.id.item_image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]

        val bookName = context.resources.getString(item.nameResourceId)
        val bookAuthor = context.resources.getString(item.authorResourceId)
        holder.textView.text = bookName.plus("\n").plus(bookAuthor)

        holder.imageView.setImageResource(item.imageResourceId)

        if (!isLinearLayoutManager) {
            holder.imageView.layoutParams.width /= 3
            holder.imageView.layoutParams.height /= 3
            holder.textView.textSize /= 5
        }

        holder.imageView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("book", Json.encodeToString(item))
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return dataset.size
    }
}