package com.example.jidibo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.jidibo.databinding.ActivityDetailBinding
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

class DetailActivity : AppCompatActivity() {

    lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val selectedBook = Json.decodeFromString<Book>(intent?.extras?.getString("book").toString())

        binding.recyclerViewDetail.adapter = ItemDetailAdapter(this, selectedBook)
        binding.recyclerViewDetail.setHasFixedSize(true)
    }
}