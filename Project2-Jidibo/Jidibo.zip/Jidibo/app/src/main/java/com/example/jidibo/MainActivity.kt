package com.example.jidibo

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.jidibo.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isLinearLayoutManager = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        chooseLayout()
    }

    private fun getMyDataSet(): List<Book> {
        return DataSource().loadBooks()
    }

    private fun chooseLayout() {
        binding.recyclerView.layoutManager =
            if (isLinearLayoutManager) LinearLayoutManager(this)
            else GridLayoutManager(this, 3)
        binding.recyclerView.adapter = ItemAdapter(this, getMyDataSet(), isLinearLayoutManager)
        binding.recyclerView.setHasFixedSize(true)
    }

    private fun setIcon(menuItem: MenuItem?) {
        if (menuItem == null)
            return

        menuItem.icon =
            if (isLinearLayoutManager) ContextCompat.getDrawable(this, R.drawable.ic_linear_layout)
            else ContextCompat.getDrawable(this, R.drawable.ic_grid_layout)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.layout_menu, menu)
        setIcon(menu?.findItem(R.id.action_switch_layout))
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_switch_layout -> {
                isLinearLayoutManager = !isLinearLayoutManager
                chooseLayout()
                setIcon(item)
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}