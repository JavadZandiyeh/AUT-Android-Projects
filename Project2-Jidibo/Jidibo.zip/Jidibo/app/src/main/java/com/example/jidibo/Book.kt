package com.example.jidibo

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes
import kotlinx.serialization.Serializable

@Serializable
data class Book(
    @DrawableRes val imageResourceId: Int,
    @StringRes val nameResourceId: Int,
    @StringRes val authorResourceId: Int,
    @StringRes val publisherResourceId: Int,
    @StringRes val yearOfPublicationResourceId: Int,
    @StringRes val versionResourceId: Int,
    @StringRes val descriptionResourceId: Int
)