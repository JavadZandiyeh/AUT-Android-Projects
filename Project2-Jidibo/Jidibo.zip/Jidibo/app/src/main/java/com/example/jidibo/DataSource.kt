package com.example.jidibo

import androidx.annotation.StringRes

class DataSource {
    fun loadBooks(): List<Book> {
        return listOf(
            Book(
                R.drawable.ketab_khaneh_nimeh_shab,
                R.string.name_135607,
                R.string.author_135607,
                R.string.publisher_135607,
                R.string.yearOfPublication_135607,
                R.string.version_135607,
                R.string.description_135607
            ),
            Book(
                R.drawable.shoja_bash_dokhtar,
                R.string.name_135416,
                R.string.author_135416,
                R.string.publisher_135416,
                R.string.yearOfPublication_135416,
                R.string.version_135416,
                R.string.description_135416,
            ),
            Book(
                R.drawable.bazi_boland_modat,
                R.string.name_136868,
                R.string.author_135416,
                R.string.publisher_136868,
                R.string.yearOfPublication_136868,
                R.string.version_136868,
                R.string.description_136868,
            ),
            Book(
                R.drawable.asar_morakkab,
                R.string.name_136128,
                R.string.author_136128,
                R.string.publisher_136128,
                R.string.yearOfPublication_136128,
                R.string.version_136128,
                R.string.description_136128,
            ),
            Book(
                R.drawable.honar_dar_lahze_zendeghi_kardan,
                R.string.name_135377,
                R.string.author_135377,
                R.string.publisher_135377,
                R.string.yearOfPublication_135377,
                R.string.version_135377,
                R.string.description_135377,
            ),
            Book(
                R.drawable.jenayat_na_mahsos,
                R.string.name_64314,
                R.string.author_64314,
                R.string.publisher_64314,
                R.string.yearOfPublication_64314,
                R.string.version_64314,
                R.string.description_64314
            )
        )
    }
}