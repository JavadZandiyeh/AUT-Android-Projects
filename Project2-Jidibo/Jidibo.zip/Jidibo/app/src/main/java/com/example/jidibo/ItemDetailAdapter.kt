package com.example.jidibo

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter for the [RecyclerView] in [DetailActivity].
 */
class ItemDetailAdapter(
    private val context: Context,
    private val book: Book
) : RecyclerView.Adapter<ItemDetailAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.item_image)
        val nameTextView: TextView = view.findViewById(R.id.item_name)
        val authorTextView: TextView = view.findViewById(R.id.item_author)
        val publisherTextView: TextView = view.findViewById(R.id.item_publisher)
        val yearOfPublicationTextView: TextView = view.findViewById(R.id.item_year_of_publication)
        val versionTextView: TextView = view.findViewById(R.id.item_version)
        val descriptionTextView: TextView = view.findViewById(R.id.item_description)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_list_detail, parent, false)

        return ItemDetailAdapter.ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.imageView.setImageResource(book.imageResourceId)
        holder.nameTextView.text = "نام کتاب: ".plus(context.resources.getString(book.nameResourceId))
        holder.authorTextView.text = "نویسنده: ".plus(context.resources.getString(book.authorResourceId))
        holder.publisherTextView.text = "ناشر: ".plus(context.resources.getString(book.publisherResourceId))
        holder.yearOfPublicationTextView.text = "سال نشر: ".plus(context.resources.getString(book.yearOfPublicationResourceId))
        holder.versionTextView.text = "نسخه: ".plus(context.resources.getString(book.versionResourceId))
        holder.descriptionTextView.text = context.resources.getString(book.descriptionResourceId)
    }

    override fun getItemCount(): Int {
        return 1
    }
}