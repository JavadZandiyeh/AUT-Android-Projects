package com.example.hafezpoem

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val poemArray = arrayOf(
            getString(R.string.poem49),
            getString(R.string.poem114),
            getString(R.string.poem246),
            getString(R.string.poem388),
            getString(R.string.poem489),
        )
        for ((index, element) in poemArray.withIndex()) {
            poemArray[index] = element.replace("\n", "\n")
        }

        val contentTextView: TextView = findViewById(R.id.poemTextView)

        val getPoemButton: Button = findViewById(R.id.getPoemButton)
        getPoemButton.setOnClickListener {
            contentTextView.text = poemArray.random()
        }

        val aboutButton: Button = findViewById(R.id.aboutButton)
        aboutButton.setOnClickListener {
            contentTextView.text = getString(R.string.about_description)
        }
    }
}